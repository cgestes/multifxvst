// SkinSliderDlg.h : header file
//

#if !defined(AFX_SKINSLIDERDLG_H__CB6DD494_241A_4D2B_B2D1_AB3CA93577C6__INCLUDED_)
#define AFX_SKINSLIDERDLG_H__CB6DD494_241A_4D2B_B2D1_AB3CA93577C6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSkinSliderDlg dialog

#include "ZipSliderCtl.h"


class CSkinSliderDlg : public CDialog
{
// Construction
public:
	CSkinSliderDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSkinSliderDlg)
	enum { IDD = IDD_SKINSLIDER_DIALOG };
	CZipSliderCtl	m_SpecialVert;
	CZipSliderCtl	m_NormVert;
	CZipSliderCtl	m_DynamicSlider;
	CZipSliderCtl	m_OrgSlider;
	CZipSliderCtl	m_sliderCtl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSkinSliderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSkinSliderDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRadio1();
	afx_msg void OnChangeDisplay();
	afx_msg void OnTT();
	afx_msg void OnStatictt();
	afx_msg void OnTracktt();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SKINSLIDERDLG_H__CB6DD494_241A_4D2B_B2D1_AB3CA93577C6__INCLUDED_)
