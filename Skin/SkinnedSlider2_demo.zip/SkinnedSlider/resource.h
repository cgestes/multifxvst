//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SkinSlider.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SKINSLIDER_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDB_SEEKBAR_BACK                129
#define IDB_SEEKBAR_TICK                130
#define IDC_CURSOR_SEEK                 131
#define IDB_SLIDETEST                   133
#define IDB_SLIDE                       135
#define IDB_NORMSEL                     136
#define IDB_SB_TS                       137
#define IDB_BLUE_NORMSEL                138
#define IDB_BLUE_NORM                   139
#define IDB_SLIDE_VERT                  140
#define IDB_TICK_VERT                   141
#define IDB_TICK_VERTSEL                142
#define IDB_BITMAP2                     144
#define IDB_RAMP                        145
#define IDB_BLOB                        146
#define IDC_SLIDER1                     1000
#define IDC_SLIDER2                     1001
#define IDC_SLIDER3                     1002
#define IDC_CHECK1                      1004
#define IDC_SLIDER4                     1005
#define IDC_BUTTON1                     1006
#define IDC_NOTT                        1007
#define IDC_STATICTT                    1008
#define IDC_TRACKTT                     1009
#define IDC_SLIDER6                     1011
#define IDC_SLIDER7                     1012
#define IDC_SLIDER8                     1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
