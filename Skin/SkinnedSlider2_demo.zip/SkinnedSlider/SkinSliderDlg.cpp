// SkinSliderDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SkinSlider.h"
#include "SkinSliderDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSkinSliderDlg dialog

CSkinSliderDlg::CSkinSliderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSkinSliderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSkinSliderDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSkinSliderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSkinSliderDlg)
	DDX_Control(pDX, IDC_SLIDER8, m_SpecialVert);
	DDX_Control(pDX, IDC_SLIDER7, m_NormVert);
	DDX_Control(pDX, IDC_SLIDER4, m_DynamicSlider);
	DDX_Control(pDX, IDC_SLIDER3, m_OrgSlider);
	DDX_Control(pDX, IDC_SLIDER1, m_sliderCtl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSkinSliderDlg, CDialog)
	//{{AFX_MSG_MAP(CSkinSliderDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CHECK1, OnRadio1)
	ON_BN_CLICKED(IDC_BUTTON1, OnChangeDisplay)
	ON_BN_CLICKED(IDC_NOTT, OnTT)
	ON_BN_CLICKED(IDC_STATICTT, OnTT)
	ON_BN_CLICKED(IDC_TRACKTT, OnTT)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSkinSliderDlg message handlers

BOOL CSkinSliderDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	CheckRadioButton(IDC_NOTT, IDC_TRACKTT, IDC_STATICTT);

	m_sliderCtl.SetSkin(IDB_SLIDE, IDB_BLUE_NORM, IDB_BLUE_NORMSEL, BG_STARTATICK | BG_CENTER_ONTICK | BG_STRETCH_HOR);
	m_sliderCtl.SetRange(0,15000);

	m_OrgSlider.SetSkin(IDB_SEEKBAR_BACK, IDB_SEEKBAR_TICK, IDB_SB_TS, BG_STARTATICK | BG_STRETCH_HOR);
	m_OrgSlider.SetRange(0,15000);

	m_DynamicSlider.SetSkin(0, IDB_SLIDETEST, IDB_NORMSEL, BG_CENTER_ONTICK | BG_SHOW_TOOLTIP);
	m_DynamicSlider.SetRange(0,100);

	m_NormVert.SetSkin(IDB_SLIDE_VERT, IDB_TICK_VERT, IDB_TICK_VERTSEL, BG_STARTATICK_VERT | BG_CENTER_ONTICK_VERT | BG_STRETCH_VERT);
	m_NormVert.SetRange(0,15000);

	m_SpecialVert.SetSkin(IDB_RAMP, IDB_BLOB, 0, BG_STRETCH_VERT);
	m_SpecialVert.SetRange(0,15000);

	OnChangeDisplay();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSkinSliderDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CSkinSliderDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CSkinSliderDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSkinSliderDlg::OnRadio1() 
{
	if (IsDlgButtonChecked(IDC_CHECK1))
		m_OrgSlider.SetCursor(IDC_CURSOR_SEEK);
	else
		m_OrgSlider.SetCursor(NULL);
}

void CSkinSliderDlg::OnChangeDisplay() 
{
	HDC hDC = m_DynamicSlider.GetBackgroundDC();

	CRect Area = m_DynamicSlider.GetClientArea();
	// Clear background
	HBRUSH hBR = CreateSolidBrush(GetSysColor(COLOR_3DFACE));
	::FillRect(hDC, Area, hBR);
	::DeleteObject(hBR);

	int MidPoint = 12;
	::MoveToEx(hDC, iMarginWidth, MidPoint, 0);
	::LineTo(hDC, Area.Width() - iMarginWidth, MidPoint);

	int NumThings = 20;
	double Pos = iMarginWidth;
	double Inc = ((double)(Area.Width() - iMarginWidth * 2)) / NumThings;
	int Depth;
	for (int i = 0; i < NumThings + 1; i++)
	{
		if (i % 2)
			Depth = 2;
		else
			Depth = 4;

		::MoveToEx(hDC, (int)Pos, MidPoint + Depth, 0);
		::LineTo(hDC, (int)Pos, MidPoint - Depth);

		Pos += Inc;
	}
	HPEN hPen = CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
	HPEN hPenOld = (HPEN)::SelectObject(hDC, hPen);
	Depth = 11;
	NumThings = rand() % 15 + 5;
	for (i = 0; i < NumThings; i++)
	{
		Pos = iMarginWidth + (rand() % (Area.Width() - iMarginWidth * 2));
		::MoveToEx(hDC, (int)Pos, MidPoint + Depth, 0);
		::LineTo(hDC, (int)Pos, MidPoint - Depth - 1);

		Pos += Inc;
	}
	::SelectObject(hDC, hPenOld);
	::DeleteObject(hPen);

	m_DynamicSlider.Invalidate(FALSE);
}

void CSkinSliderDlg::OnTT() 
{
	int Checked = GetCheckedRadioButton(IDC_NOTT, IDC_TRACKTT);

	int Options = 0;
	if (Checked == IDC_STATICTT)
		Options = BG_SHOW_TOOLTIP;
	if (Checked == IDC_TRACKTT)
		Options = BG_SHOW_TOOLTIP_TRACK;

	m_DynamicSlider.SetupTT(Options);
}
